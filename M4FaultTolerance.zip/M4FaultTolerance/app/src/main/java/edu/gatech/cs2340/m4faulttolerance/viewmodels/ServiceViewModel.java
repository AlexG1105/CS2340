package edu.gatech.cs2340.m4faulttolerance.viewmodels;


import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;
import android.widget.Toast;

import edu.gatech.cs2340.m4faulttolerance.services.BadService;
import edu.gatech.cs2340.m4faulttolerance.services.NormalService;
import edu.gatech.cs2340.m4faulttolerance.services.RetryService;
import edu.gatech.cs2340.m4faulttolerance.services.SimulatedService;
import edu.gatech.cs2340.m4faulttolerance.services.SlowService;
import io.github.jolly.circuitbreaker.CircuitBreakerPolicy;
import io.github.jolly.circuitbreaker.CircuitBreakerPolicyBuilder;
import io.github.jolly.fallback.FallbackPolicy;
import io.github.jolly.fallback.FallbackPolicyBuilder;
import io.github.jolly.retry.RetryPolicy;
import io.github.jolly.retry.RetryPolicyBuilder;
import io.github.jolly.timeout.TimeoutPolicy;
import io.github.jolly.timeout.TimeoutPolicyBuilder;


/**
 * View Model for our fault tolerant app
 */
public class ServiceViewModel extends AndroidViewModel {

    /**
     * Make a new view model,  system should call this automatically for us
     * @param application
     */
    public ServiceViewModel(@NonNull Application application) {
        super(application);
    }

    /**
     * Normal request for service, always succeeds
     *
     * @param request  the service request
     *
     * @return whatever comes back from the service
     */
    public String makeNormalRequest(String request) {
        SimulatedService normalService = new NormalService(request);
        SimulatedService badService = new BadService(request);

        CircuitBreakerPolicy pol = new CircuitBreakerPolicyBuilder()
                .rateThreshold(100)
                .sizeRingBufferHalfOpen(2)
                .sizeRingBufferClosed(4)
                .build();
        try {

            try {
                System.out.println("CB Result 1: " + pol.exec(badService::executeTheService));
            } catch (Exception ex) {
                System.err.println("Bad Call through CB: " + ex.toString());
            }

            try {
                System.out.println("CB Result 2: " + pol.exec(badService::executeTheService));
            } catch (Exception ex) {
                System.err.println("Bad Call through CB: " + ex.toString());
            }

            try {
                System.out.println("CB Result 3: " + pol.exec(badService::executeTheService));

            } catch (Exception ex) {
                System.err.println("Bad Call through CB: " + ex.toString());
            }

            return (String) pol.exec(normalService::executeTheService);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public String makeBadRequest(String request) {
        SimulatedService service = new BadService(request);
        SimulatedService backupService = new NormalService(request);
        FallbackPolicy<String> pol = new FallbackPolicyBuilder<String>(backupService::executeTheService).build();

        try {
            return service.executeTheService();
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            return pol.exec(service::executeTheService);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;
    }

    public String makeSlowRequest(String request) {
        SimulatedService service = new SlowService(request);

        TimeoutPolicy<String> pol = new TimeoutPolicyBuilder<String>().duration(1000).build();
        try {
            String response = pol.exec(service::executeTheService);
            if (response == null) return "Timeout Happened!";
        } catch (RuntimeException ex) {
            ex.printStackTrace();
        }

        return null;
    }

    public String makeRetryRequest(String request) {
        SimulatedService service = new RetryService(request);
        try {
            return service.executeTheService();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        RetryPolicy<String> retryPolicy = new RetryPolicyBuilder<String>().attempts(4).waitDuration(500).build();
        try {
            return retryPolicy.exec(service::executeTheService);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return "Bad Result";
    }
}
